// script.js
let users = [];
let currentUser = null;
let transactions = [];

function showLogin() {
  document.getElementById('registration').classList.add('hidden');
  document.getElementById('login').classList.remove('hidden');
}

function showDashboard() {
  document.getElementById('login').classList.add('hidden');
  document.getElementById('dashboard').classList.remove('hidden');
}

function showRegister() {
  document.getElementById('login').classList.add('hidden');
  document.getElementById('registration').classList.remove('hidden');
}

function register() {
  const username = document.getElementById('register-username').value;
  const password = document.getElementById('register-password').value;

  if (!username || !password) {
    alert('Please fill in all fields');
    return;
  }

  if (users.find(user => user.username === username)) {
    alert('User already exists');
    return;
  }

  users.push({ username, password });
  alert('Registration successful');
  showLogin();
}

function login() {
  const username = document.getElementById('login-username').value;
  const password = document.getElementById('login-password').value;

  const user = users.find(user => user.username === username && user.password === password);
  if (user) {
    currentUser = user;
    showDashboard();
  } else {
    alert('Invalid credentials');
  }
}

function logout() {
  currentUser = null;
  document.getElementById('dashboard').classList.add('hidden');
  document.getElementById('login').classList.remove('hidden');
}

function addTransaction() {
  const desc = document.getElementById('transaction-desc').value;
  const amount = parseFloat(document.getElementById('transaction-amount').value);

  if (!desc || isNaN(amount)) {
    alert('Please enter valid details');
    return;
  }

  transactions.push({ desc, amount });
  updateTransactions();
}

function updateTransactions() {
  const list = document.getElementById('transactions-list');
  list.innerHTML = '';

  let totalAmount = 0;

  transactions.forEach((transaction, index) => {
    totalAmount += transaction.amount;

    const li = document.createElement('li');
    li.textContent = ${transaction.desc}; $${transaction.amount.toFixed(2)};
    list.appendChild(li);
  });

  document.getElementById('total-transactions').textContent = transactions.length;
  document.getElementById('total-amount').textContent = $${totalAmount.toFixed(2)};
}